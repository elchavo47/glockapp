//
//  Bridging-Header.h
//  SockPwn Real
//

#ifndef BRIDGING_HEADER_H
#define BRIDGING_HEADER_H

#import "SPRJailbreak.h"
#import "worse_query.h"

#endif
