//
//  Bridging-Header.h
//  SockPwn
//

#ifndef BRIDGING_HEADER_H
#define BRIDGING_HEADER_H

#import "SPRJailbreak.h"
#import "SPFullJailbreak.h"
#import "SP_KernelRW.h"
#import "SP_MTEBypass.h"
#import "SP_PACBypass.h"
#import "SP_PPLBypass.h"
#import "worse_query.h"
#import "DOBootstrapper.h"
#import "DOEnvironmentManager.h"
#import "DOExploit.h"
#import "DOExploitManager.h"
#import "DOJailbreaker.h"
#import "multicast_bytecopy.h"


// wq_ / Container-manager escape (from Bridging-Header_3dec58.h)
#include <stdint.h>
int64_t wq_grant(const char *target, const char *group, uint64_t flags);
void wq_revoke(int64_t handle);
int wq_group_available(const char *group);
int64_t wq_token(const char *identifier, uint64_t cls, uint64_t part, uint64_t flags, const char *partDomain);

// SockUafSpray (from AGXProbe-Bridging-Header.h)
#include <stddef.h>
int sockuaf_ool_spray(size_t size, int count, uint64_t fill);
void sockuaf_ool_reset(void);
int sockuaf_ool_count(void);
int cow_probe_run(int rounds, int size_kb, int *stages);
int cow_file_probe(int rounds, int size_kb, const char *dir, int *stages);
int apfs_race_probe(int rounds, int size_kb, const char *dir, int *stages);
int network_surface_probe(void);
int route_socket_probe(int *stages);
int vm_reclaim_probe(int *stages);

// C logging bridge
void log_from_c(const char* msg);

// ANE / IOSurface probes
int trigger_ane_direct(void);
void run_decmpfs_leak(const char *base_dir);
void run_iosurface_notify_probe(void);

#endif
