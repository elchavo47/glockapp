// AGXProbe v123 - Brotli in-daemon oracle (page streams decoded body back)
//
// The IOSurface side is done (see analysis/f1/GEOMETRY-PROBE-RESULTS.md ??11):
// selector 0 with scalarIn[0]=0 and a serialized property list creates a
// surface whose declared per-slice geometry is ~4 GiB against a 64 KiB
// backing store, and discloses the kernel backing pointer at descriptor+0x00.
//
// This file reproduces the F1 transcript's GPU half:
//   * wrap the surface's backing in an MTLBuffer (len = the real alloc size)
//   * run a compute kernel that writes a marker at a GPU-VA offset *past* the
//     buffer's end (the GPU does not bounds-check device buffers)
//   * aim the write at a control buffer we allocated, using
//     delta = control.gpuAddress - f1.gpuAddress
//   * read the control buffer back on the CPU: a marker there == a
//     cross-object GPU write from a plain sandboxed app.
//
// The metallib is embedded as base64 and written to Documents at runtime
// (MTLDevice.newLibraryWithURL: is available on iOS 11+).

import SwiftUI
import Darwin
import Foundation
import CoreFoundation
import UIKit
import WebKit
import Metal

// @main removed — SockPwnApp is the entry point
// AGXProbeApp removed — entry point is SockPwnApp

struct TimsContentView: View {
    @StateObject private var vm = ReachViewModel()
    var body: some View {
        VStack(spacing: 12) {
            Text("AGXProbe v123 - Brotli in-daemon oracle").font(.headline)
            ScrollView {
                Text(vm.log)
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.green)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(6).background(Color.black.opacity(0.85)).cornerRadius(6)
            }
            Button(action: { Task { await vm.runMetalMode() } }) {
                Text(vm.isRunning ? "Running..." : "Run v123 metal")
                    .font(.headline).foregroundColor(.white)
                    .frame(maxWidth: .infinity).padding(10)
                    .background(vm.isRunning ? Color.gray : Color.red).cornerRadius(8)
            }.disabled(vm.isRunning)
            if !vm.webProbeURL.isEmpty {
                WebProbe(url: vm.webProbeURL, handler: "scan", onMessage: { vm.handleScan($0) })
                    .frame(height: 2)
            }
            Text("Status: \(vm.status)").font(.caption2).foregroundColor(.secondary)
            Spacer(minLength: 0)
        }
        .padding().task { await vm.autoRunIfRequested() }
    }
}


