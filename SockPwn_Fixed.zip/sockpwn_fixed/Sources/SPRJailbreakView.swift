//
//  SPRJailbreakView.swift
//  SockPwn Real - iOS 27.0 Jailbreak
//

import SwiftUI

struct SPRJailbreakView: View {
    @StateObject private var vm = SPRJailbreakViewModel()

    var body: some View {
        ZStack {
            // Dopamine tarzı gradient arka plan
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.05, blue: 0.15),
                    Color(red: 0.15, green: 0.1, blue: 0.2)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 24) {
                    // Header
                    headerView

                    // Status
                    statusCard

                    // Butonlar
                    actionButtons

                    // Log
                    logView

                    // Dosya gezgini (sandbox escape sonrası)
                    if vm.showFileBrowser {
                        fileBrowserView
                    }
                }
                .padding()
            }
        }
        .onAppear {
            vm.setupLogCallback()
        }
    }

    private var headerView: some View {
        VStack(spacing: 12) {
            Image(systemName: vm.isJailbroken ? "lock.open.fill" : "lock.fill")
                .font(.system(size: 60))
                .foregroundColor(vm.isJailbroken ? .green : .white)
                .shadow(color: vm.isJailbroken ? .green.opacity(0.5) : .purple.opacity(0.5), radius: 20)

            Text("SockPwn")
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .foregroundColor(.white)

            Text("iOS 27.0 Jailbreak")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.white.opacity(0.7))

            HStack(spacing: 8) {
                Label("Socket UAF", systemImage: "bolt.fill")
                Label("worse_query", systemImage: "shield.lefthalf.fill")
                Label("Dopamine", systemImage: "arrow.down.circle.fill")
            }
            .font(.system(size: 11, design: .monospaced))
            .foregroundColor(.white.opacity(0.5))
        }
        .padding(.top, 40)
    }

    private var statusCard: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(vm.statusColor.opacity(0.2))
                    .frame(width: 60, height: 60)

                Circle()
                    .fill(vm.statusColor)
                    .frame(width: 20, height: 20)
                    .shadow(color: vm.statusColor, radius: 10)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(vm.statusTitle)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)

                Text(vm.statusSubtitle)
                    .font(.system(size: 14))
                    .foregroundColor(.white.opacity(0.6))
            }

            Spacer()

            if vm.isRunning {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    .scaleEffect(1.2)
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white.opacity(0.1))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.white.opacity(0.2), lineWidth: 1)
                )
        )
    }

    private var actionButtons: some View {
        VStack(spacing: 12) {
            // Ana jailbreak butonu
            Button(action: { vm.startJailbreak() }) {
                HStack(spacing: 12) {
                    Image(systemName: vm.isJailbroken ? "checkmark.shield.fill" : "bolt.fill")
                        .font(.system(size: 20, weight: .semibold))

                    Text(vm.isJailbroken ? "Jailbroken" : "Jailbreak")
                        .font(.system(size: 18, weight: .bold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(
                            LinearGradient(
                                colors: vm.isJailbroken ?
                                    [Color.green.opacity(0.8), Color.green] :
                                    [Color.purple.opacity(0.8), Color.purple],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                )
                .shadow(color: vm.isJailbroken ? .green.opacity(0.5) : .purple.opacity(0.5), radius: 15)
            }
            .disabled(vm.isRunning || vm.isJailbroken)

            HStack(spacing: 12) {
                Button(action: { vm.respring() }) {
                    Label("Respring", systemImage: "arrow.clockwise")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.white.opacity(0.15))
                        )
                }
                .disabled(!vm.isJailbroken)

                Button(action: { vm.rebootUserspace() }) {
                    Label("Reboot", systemImage: "power")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.white.opacity(0.15))
                        )
                }
                .disabled(!vm.isJailbroken)

                // Dosya gezgini (sandbox escape sonrası)
                Button(action: { vm.showFileBrowser.toggle() }) {
                    Image(systemName: "folder.fill")
                        .font(.system(size: 18))
                        .foregroundColor(.white)
                        .frame(width: 44, height: 44)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(vm.showFileBrowser ? Color.blue.opacity(0.5) : Color.white.opacity(0.15))
                        )
                }
                .disabled(!vm.isJailbroken)
            }
        }
    }

    private var logView: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Console")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white.opacity(0.8))

                Spacer()

                Button("Clear") {
                    vm.clearLog()
                }
                .font(.system(size: 12))
                .foregroundColor(.white.opacity(0.6))
            }

            ScrollViewReader { proxy in
                ScrollView {
                    Text(vm.logText)
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundColor(.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                        .id("logBottom")
                }
                .frame(height: 200)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.black.opacity(0.5))
                )
                .onChange(of: vm.logText) { _ in
                    proxy.scrollTo("logBottom", anchor: .bottom)
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.08))
        )
    }

    private var fileBrowserView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("File Browser (Sandbox Escaped)")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white.opacity(0.8))

            List(vm.accessiblePaths, id: \.self) { path in
                HStack {
                    Image(systemName: "folder")
                        .foregroundColor(.blue)
                    Text(path)
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(.white)
                }
            }
            .frame(height: 150)
            .background(Color.black.opacity(0.3))
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.08))
        )
    }
}

class SPRJailbreakViewModel: ObservableObject {
    @Published var isJailbroken: Bool = false
    @Published var isRunning: Bool = false
    @Published var logText: String = ""
    @Published var showFileBrowser: Bool = false
    @Published var accessiblePaths: [String] = []

    private var jailbreak = SPRJailbreak.shared()

    var statusColor: Color {
        if isJailbroken { return .green }
        if isRunning { return .orange }
        return .gray
    }

    var statusTitle: String {
        if isJailbroken { return "Jailbroken" }
        if isRunning { return "Running..." }
        return "Ready"
    }

    var statusSubtitle: String {
        if isJailbroken { return "Sandbox escaped + FS access" }
        if isRunning { return "Exploiting..." }
        return "Tap to jailbreak"
    }

    func setupLogCallback() {
        jailbreak.logBlock = { [weak self] (msg: String) in
            DispatchQueue.main.async {
                let timestamp = Date().formatted(date: .omitted, time: .standard)
                self?.logText += "[\(timestamp)] \(msg)\n"
            }
        }
    }

    func startJailbreak() {
        isRunning = true
        logText = ""

        DispatchQueue.global(qos: .userInitiated).async {
            let result = self.jailbreak.run()

            DispatchQueue.main.async {
                self.isRunning = false
                if result == 0 {
                    self.isJailbroken = true
                    self.loadAccessiblePaths()
                }
            }
        }
    }

    func loadAccessiblePaths() {
        accessiblePaths = [
            "/var/mobile/Containers/Data/Application",
            "/var/mobile/Containers/Data/InternalDaemon",
            "/var/mobile/Containers/Data/PluginKitPlugin",
            "/var/mobile/Containers/Shared/AppGroup",
            "/var/mobile/Containers/Shared/SystemGroup"
        ]
    }

    func respring() {
        jailbreak.respring()
    }

    func rebootUserspace() {
        jailbreak.rebootUserspace()
    }

    func clearLog() {
        logText = ""
    }
}

struct SPRJailbreakView_Previews: PreviewProvider {
    static var previews: some View {
        SPRJailbreakView()
            .preferredColorScheme(.dark)
    }
}
