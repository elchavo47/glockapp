#ifndef __MCAST_H__
#define __MCAST_H__

extern int mcast_race_sock;

void mcast_increase_race_reliability(void);
int mcast_join_group(int ip);

#endif
