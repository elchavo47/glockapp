//
//  SPFullJailbreak.h
//  SockPwn - Full Jailbreak
//

#ifndef SPFULLJAILBREAK_H
#define SPFULLJAILBREAK_H

#import <Foundation/Foundation.h>

typedef enum {
    SPFullStateIdle = 0,
    SPFullStateSandboxEscape,
    SPFullStateKernelRW,
    SPFullStateMTEBypass,
    SPFullStatePACBypass,
    SPFullStatePPLBypass,
    SPFullStateBootstrap,
    SPFullStateDone,
    SPFullStateFailed
} SPFullState;

@interface SPFullJailbreak : NSObject

@property (nonatomic, copy) void (^logBlock)(NSString *msg);
@property (nonatomic, readonly) SPFullState state;
@property (nonatomic, readonly) BOOL isJailbroken;
@property (nonatomic, readonly) uint64_t kernelBase;

+ (instancetype)shared;
- (int)run;
- (void)respring;
- (void)rebootUserspace;

@end

#endif
