//
//  SP_MTEBypass.h
//  SockPwn - MTE Bypass
//

#ifndef SP_MTEBYPASS_H
#define SP_MTEBYPASS_H

#include <stdint.h>

int sp_mte_bypass(uint64_t untagged_addr, uint64_t *tagged_addr);

#endif
