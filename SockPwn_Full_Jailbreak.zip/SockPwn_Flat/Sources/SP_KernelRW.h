//
//  SP_KernelRW.h
//  SockPwn - Kernel RW Primitive
//

#ifndef SP_KERNELRW_H
#define SP_KERNELRW_H

#include <stdint.h>

int sp_kernel_rw_init(void);
uint32_t sp_kread32(uint64_t kaddr);
uint64_t sp_kread64(uint64_t kaddr);
void sp_kwrite32(uint64_t kaddr, uint32_t val);
void sp_kwrite64(uint64_t kaddr, uint64_t val);
int sp_kernel_rw_test(void);
uint64_t sp_get_kernel_base(void);
uint64_t sp_get_kaslr_slide(void);

#endif
