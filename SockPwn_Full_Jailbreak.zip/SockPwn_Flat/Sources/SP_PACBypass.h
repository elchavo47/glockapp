//
//  SP_PACBypass.h
//  SockPwn - PAC Bypass
//

#ifndef SP_PACBYPASS_H
#define SP_PACBYPASS_H

#include <stdint.h>

int sp_pac_bypass(uint64_t pointer, uint64_t context, uint64_t *signed_ptr);

#endif
