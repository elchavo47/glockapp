//
//  SPRJailbreak.h
//  SockPwn Real - iOS 27.0 Jailbreak
//

#ifndef SPRJAILBREAK_H
#define SPRJAILBREAK_H

#import <Foundation/Foundation.h>

typedef enum {
    SPRJBStateIdle = 0,
    SPRJBStateSandboxEscape,
    SPRJBStateKernelExploit,
    SPRJBStateKernelRW,
    SPRJBStateBootstrap,
    SPRJBStateDone,
    SPRJBStateFailed
} SPRJBState;

@interface SPRJailbreak : NSObject

@property (nonatomic, copy) void (^logBlock)(NSString *msg);
@property (nonatomic, readonly) SPRJBState state;
@property (nonatomic, readonly) BOOL isJailbroken;

+ (instancetype)shared;
- (int)run;
- (void)respring;
- (void)rebootUserspace;

@end

#endif
