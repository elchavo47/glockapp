//
//  SockPwnApp.swift
//  SockPwn Real - iOS 27.0 Jailbreak
//

import SwiftUI

@main
struct SockPwnApp: App {
    var body: some Scene {
        WindowGroup {
            SPRJailbreakView()
                .preferredColorScheme(.dark)
        }
    }
}
