//
//  SP_PPLBypass.h
//  SockPwn - PPL Bypass
//

#ifndef SP_PPLBYPASS_H
#define SP_PPLBYPASS_H

#include <stdint.h>

int sp_ppl_bypass(uint64_t kernel_base, uint64_t kaslr_slide);

#endif
