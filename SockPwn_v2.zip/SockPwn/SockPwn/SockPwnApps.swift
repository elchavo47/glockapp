//
// SockPwnApps.swift
// glock
//
// Created by Anonym on 15.11.26.
//

import SwiftUI

@main
struct SockPwnApp: App {
    var body: some Scene {
        WindowGroup {
            ExploitView()
        }
    }
}
